-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 08:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `first_name` varchar(30) DEFAULT NULL,
  `second_name` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `Email` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`first_name`, `second_name`, `phone`, `Email`, `password`) VALUES
('', ' BVVNVN', '', '', ''),
('', ' BVVNVN', '', '', ''),
('FF', 'FF', 'FF', 'FF', 'FF'),
('FFFFF', 'FFFFF', 'FFFFF', 'FFFFFSAS', 'FFFFFSAS'),
('WEWE', 'TATA', '0789', 'KOKOKO', '888'),
('GFFGH', 'GFH', 'GGFGGFGF', 'BEBEBE', '7878'),
('TYTYT', 'NBNBB', '089', 'TETATA', '7777'),
('TYTYT', 'NBNBB', '089', 'TETATA', '7777'),
('MAMA', 'NANA', '0789', 'WELCO', '9090'),
('teta', 'keza', '0789', 'vava', 'aime'),
('bvvbb', 'nbbvvbvb', '0789', 'fabu', 'keza'),
('errt', 'gty', 'ghgh', 'fabu', 'keza'),
('x', 'x', 'x', 'x', 'x'),
('xxxx', 'xxxx', 'xxxx', 'xxxx', 'xxxx'),
('1111', '1111', '1111', '1111', '1111'),
('1', '1', '1', '1', '1'),
('11', '11', '11', '11', '11'),
('11', '11', '11', '1', '1'),
('111', '1111', '111', '111', '1'),
('111', '111', '111', '1', '111'),
('ssss', 'ssss', 'ssss', 'ssss', 'ssss'),
('s', 's', 's', 's', 's'),
('sss', 'sss', 'sss', 'sss', 'sss'),
('uyuyuyyy', 'jjjjkkkkk', '08798989', 'daniel', 'aline'),
('yttyyuuyu', 'kjjhhjgjhg', '0798990', 'www', '444'),
('aline', 'alice', '0897', 'fabu', 'keza'),
('', '', '', '', ''),
('KEKE', 'KOKO', '076899', 'WEE', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
